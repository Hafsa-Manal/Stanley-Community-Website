export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-10 page-enter">
      <h1 className="text-2xl font-bold" style={{ color: '#1a3a6b' }}>Home / Opportunities</h1>
      <p className="text-gray-500 mt-2">Coming soon...</p>
    </div>
  )
}
